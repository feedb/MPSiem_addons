
# -*- coding: utf-8 -*-
from __future__ import print_function
from __future__ import unicode_literals
from cryptography.fernet import Fernet
import datetime
import html
import json
import os.path
import re
import requests
import sys
import time
import urllib3
import logging
import logging.handlers
import socket

from urllib.parse import parse_qs          # DON'T DELETE!

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

CONFIG = "/home/script/config.json"
KRAKOZYABRA = 'abToisdfas&asdf3451-l10asdfg-1451345121234dc='
LIMIT_INC = 100     # Сколько выгружаем инцидентов за раз
OFFSET = 0          # Смещение назад относительно самого нового
LIMIT_EVENT = 1000  # Сколько выгружаем связанных с инцидентом событий за раз
INC_PERIOD = 480    # Период мониторинга инцидентов (в секундах)
VERSION = 1.3       # Версия скрипта


##################################################################
#                     Authentication
##################################################################

class AccessDenied(Exception):
    pass


def print_response(response, check_status=True):
    if check_status:
        assert response.status_code == 200
    return response


def available_applications(session, address):
    applications = print_response(session.get(address + ':3334/ptms/api/sso/v1/applications')).json()
    #print(json.dumps(applications, indent=4, sort_keys=True))

    return [
        app['id']
        for app in applications
        if is_application_available(session, app)
    ]


def is_application_available(session, app):
    if app['id'] == 'idmgr':
        modules = print_response(session.get(app['url'] + '/ptms/api/sso/v1/account/modules')).json()

        return bool(modules)

    if app['id'] == 'mpx':
        return external_auth(
            session,
            app['url'] + '/account/login?returnUrl=/#/authorization/landing'
        )


def external_auth(session, address):
    response = print_response(session.get(address))

    if 'access_denied' in response.url:
        return False

    while '<form' in response.text:
        form_action, form_data = parse_form(response.text)

        response = print_response(session.post(form_action, data=form_data))

    return True


def parse_form(data):
    return re.search('action=[\'"]([^\'"]*)[\'"]', data).groups()[0], {
        item.groups()[0]: html.unescape(item.groups()[1])
        for item in re.finditer(
            'name=[\'"]([^\'"]*)[\'"] value=[\'"]([^\'"]*)[\'"]',
            data
        )
    }


def authenticate(address, login, password, new_password=None, auth_type=0):
    session = requests.session()
    session.verify = False

    try:
        response = print_response(session.post(
            address + ':3334/ui/login',
            json=dict(
                authType=auth_type,
                username=login,
                password=password,
                newPassword=new_password
            )
        ), check_status=False)

        if response.status_code != 200:
            raise AccessDenied(response.text)

        if '"requiredPasswordChange":true' in response.text:
            raise AccessDenied(response.text)
    except:
        if 'response' in locals():
            print_log('[ERROR] {}/{}'.format(response.status_code, response.text))
        else:
            print_log('[ERROR] Check network settings or host network availability!')
        sys.exit()
    # print(available_applications(session, address))
    return session, available_applications(session, address)


def login_api(settings):
    cipher_suite = Fernet(str.encode(KRAKOZYABRA))
    export_core_pass = cipher_suite.decrypt(settings['export_core_pass'].encode('utf-8')).decode()

    settings['export_session'] = authenticate(settings['export_core_url'], settings['export_core_user'],
                                              export_core_pass, auth_type=settings['auth_type'])[0]


def available_applications_2(session, address):
    applications = print_response(session.get(address + ':3334/api/tenants/v1/menu')).json()
    # print(json.dumps(applications, indent=4, sort_keys=True))

    APP_MAPPING = {
        'PTMC': 'idmgr',
        'PT.MPSIEM': 'mpx',
        'PT.PTKB': 'ptkb'
    }

    return [
        APP_MAPPING[app['type']]
        for app in applications['children'][0]['applications']
        if is_application_available_2(session, app)
    ]


def is_application_available_2(session, app):
    if 'MC' in app['type']:
        modules = print_response(session.get(
            app['link'] + '/ptms/api/sso/v2/account/privileges'
        )).json()

        return bool(modules)

    if 'SIEM' in app['type']:
        return external_auth_2(
            session,
            app['link'] + '/account/login?returnUrl=/#/authorization/landing'
        )

    if 'PTKB' in app['type']:
        return external_auth_2(
            session,
            app['link'] + '/account/login?returnUrl=/#/statistics'
        )


def external_auth_2(session, address):
    response = print_response(session.get(address))

    if 'access_denied' in response.url:
        return False

    while '<form' in response.text:
        form_action, form_data = parse_form(response.text)

        if form_action == '/':
            form_action = re.match('^https://[^/]+', response.url).group(0)

        response = print_response(session.post(form_action, data=form_data))

    return True


def authenticate_2(address, login, password, new_password=None, auth_type=0):
    session = requests.session()
    session.verify = False

    try:
        master_response = print_response(session.get(address + ':3334/ui/login'))
        master_address = '/'.join(master_response.url.split('/')[:3]).rpartition(':')[0]

        response = print_response(session.post(
            master_address + ':3334/ui/login',
            json=dict(
                authType=auth_type,
                username=login,
                password=password,
                newPassword=new_password
            )
        ), check_status=False)

        if response.status_code != 200:
            raise AccessDenied(response.text)

        if '"requiredPasswordChange":true' in response.text:
            raise AccessDenied(response.text)

        if master_address != address:
            external_auth_2(
                session,
                master_address + ':3334' + parse_qs(master_response.url.partition('?')[2])['returnUrl'][0]
            )

    except:
        if 'response' in locals():
            print_log('[ERROR] {}/{}'.format(response.status_code, response.text))
        else:
            print_log('[ERROR] Check network settings or host network availability!')
        sys.exit()
    # print(available_applications_2(session, address))
    return session, available_applications_2(session, address)


def login_api_2(settings):
    cipher_suite = Fernet(str.encode(KRAKOZYABRA))
    export_core_pass = cipher_suite.decrypt(
        settings['export_core_pass'].encode('utf-8')).decode()

    settings['export_session'] = authenticate_2(settings['export_core_url'], settings[
        'export_core_user'], export_core_pass, auth_type=settings['auth_type'])[0]


def edit_password():
    cipher_suite = Fernet(str.encode(KRAKOZYABRA))
    print("Please enter parameter [export_core_pass] (SIEM Core Password)")
    ecp = sys.stdin.readline()
    ecp_cipher = cipher_suite.encrypt(str.encode(ecp.strip()))
    print(ecp_cipher.decode())

    update_config(ecp_cipher.decode())


def read_config():
    if not os.path.exists(CONFIG):
        print_log("[ERROR] Can't find " + CONFIG)
        sys.exit(1)
    with open(CONFIG, encoding='utf-8') as fh:
        data = fh.read()
    return json.loads(data)


def update_config(ecp_cipher):
    settings = read_config()
    settings['export_core_pass'] = ecp_cipher

    with open(CONFIG, "w", encoding='utf-8') as fh:
        json.dump(settings, fh, indent=2)


def read_processed_file(file_name):
    incident_list = []
    if not os.path.exists(file_name):
        return []
    with open(file_name, "r") as fh:
        for line in fh:
            incident_list.append(line.rstrip())
    return incident_list


def write_processed_file(file_name, incident):
    with open(file_name, "w") as fh:
        fh.write(incident + "\n")


def print_log(data):
    now = datetime.datetime.now()
    print(now.strftime("%Y-%m-%d %H:%M:%S ") + str(data))


def get_incidents_list(settings):
    unix_time = int(time.time()) - settings['time_from']
    post_params = {
        "offset": OFFSET,
        "limit": LIMIT_INC,
        "groups": {
            "filterType": "no_filter"
        },
        "timeFrom": unix_time,
        "timeTo": None,
        "filterTimeType": "creation",
        "filter": {
            "select": ["key",
                       "name",
                       "category",
                       "type",
                       "status",
                       "created",
                       "assigned"],
            "where": "",
            "orderby": [{
                "field": "created",
                "sortOrder": "descending"
            },
                {
                    "field": "status",
                    "sortOrder": "ascending"
                },
                {
                    "field": "severity",
                    "sortOrder": "descending"
                }]
        },
        "queryIds": ["all_incidents"]
    }
    res = settings['export_session'].post(
        settings['export_core_url'] + '/api/v2/incidents/', json=post_params).json()
    if "incidents" not in res:
        print_log("[ERROR] getting incidents")
        sys.exit(0)
    if not res["incidents"]:
        print_log("[INFO] Incidents not found")
        sys.exit(0)
    return res


def send_inc_to_syslog(inc, settings):
    post_params = settings['export_session'].get(settings['export_core_url'] + '/api/incidents/' + inc["id"]).json()
    count_att = 1
    while "message" in post_params and count_att < 10:
        post_params = settings['export_session'].get(settings['export_core_url'] + '/api/incidents/' + inc["id"]).json()
        print_log('Attempt ' + str(count_att) + ' FAILED to read [' + inc["key"] + ']')
        count_att += 1
        # print(json.dumps(post_params, indent=4, sort_keys=True))
        if count_att == 9:
            print_log("[ERROR] " + inc["key"] + " export FAILED to syslog")
            return
    else:
        my_logger.debug(post_params)
        print_log("[INFO] " + inc["key"] + " exported to syslog")


def run(settings):

    # if settings['debug'] == 1:
    #    print(json.dumps(settings, indent=4, sort_keys=True))

    login_api(settings)

    sent_list = read_processed_file(settings['logfile'])
    incidents = get_incidents_list(settings)

    export_flag = False
    recv_list = []  # In the list we write the number of the processed incident
    incident_counter = 0

    for incident in (reversed(incidents["incidents"])):
        inc_num = incident["key"].split('-')[-1]
        if not sent_list or (int(sent_list[-1]) < int(inc_num)):
            export_flag = False
            recv_list.append(inc_num)
            send_inc_to_syslog(incident, settings)
            incident_counter += 1
            write_processed_file(settings['logfile'], recv_list[-1])

        else:
            export_flag = True

    if export_flag:
        print_log('[INFO] Incidents before INC-' + str(sent_list[-1]) + " already have been exported")

    return incident_counter


def check_options():
    global CONFIG
    if len(sys.argv) == 1:
        return

    if sys.argv[1] == "-h":
        print("\n AVAILABLE OPTIONS:"
              "\n  -e : Edit SIEM Core password"
              "\n  -v : Script version"
              "\n  -h : Help")
        sys.exit(0)

    if sys.argv[1] == "-v":
        print("\n Version: %s" % VERSION)
        sys.exit(0)

    if sys.argv[1] == "-e":
        edit_password()
        sys.exit(0)


if __name__ == "__main__":
    start_time = time.time()

    check_options()
    conf = read_config()

    my_logger = logging.getLogger('MyLogger')
    my_logger.setLevel(logging.DEBUG)
    if conf["syslog_type"].upper() == "TCP":
        try:
            handler = logging.handlers.SysLogHandler(address=(conf["syslog_server_ip"], int(conf["syslog_server_port"])), socktype=socket.SOCK_STREAM)
        except ConnectionRefusedError:
            print_log("[WARNING] Syslog server unreachable. Check settings")
            sys.exit(1)
    else:
        handler = logging.handlers.SysLogHandler(address=(conf["syslog_server_ip"], int(conf["syslog_server_port"])))

    my_logger.addHandler(handler)
    count = run(conf)
    print_log("--- " + str(count) + " Incidents processed. " +
              "Script execution time: %.3f sec. ---" % (time.time() - start_time))
